// SH2NR feeder (64-bit). Opens the frames the 32-bit add-on shares, runs AMDNR's lmxxf neural
// runtime (LmxxfNrRuntime.dll + LmxxfNrRuntime.pak, the DLSS 5 Neural Rendering network ported to
// AMD by lmxxf) on them through D3D12 + HIP, and writes the answer back into the shared output.
// SPDX-License-Identifier: GPL-3.0-or-later
// Credits: AMDNR by 3zwr1 - https://github.com/3zwr1/AMD-NR---OptiScaler (runtime host interface,
//          LmxxfNrApi.h, and the build of LmxxfNrRuntime.dll / .pak this loads)
//          lmxxf (Kien) - https://github.com/lmxxf/dlss5-on-amd-9070xt-porting (MIT)
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <shellapi.h>
#include <d3d12.h>
#include <dxgi1_6.h>
#include <d3dcompiler.h>
#include <cstdio>
#include <cstdarg>
#include <cstring>
#include <string>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <vector>
#include "../common/sh2nr_shared.h"
#include "LmxxfNrApi.h"
// AMD FidelityFX API (MIT, AMD) - FSR 4 / FSR 3.1 upscaling, through amd_fidelityfx_loader_dx12.dll
#include "ffx_api/ffx_api.h"
#include "ffx_api/ffx_api_types.h"
#include "ffx_api/ffx_upscale.h"
#include "ffx_api/dx12/ffx_api_dx12.h"

template <class T> struct Com
{
    T *p = nullptr;
    Com() = default;
    Com(const Com &) = delete;
    Com &operator=(const Com &) = delete;
    Com(Com &&o) noexcept : p(o.p) { o.p = nullptr; }
    Com &operator=(Com &&o) noexcept { if (this != &o) { Reset(); p = o.p; o.p = nullptr; } return *this; }
    ~Com() { Reset(); }
    void Reset() { if (p) { p->Release(); p = nullptr; } }
    T *operator->() const { return p; }
    T *Get() const { return p; }
    T **Put() { Reset(); return &p; }
    explicit operator bool() const { return p != nullptr; }
};

static FILE *g_log = nullptr;
static Sh2nrShared *g_shm = nullptr;

static void Status(const char *fmt, ...)
{
    char buf[1024];
    va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof buf, fmt, ap); va_end(ap);
    if (g_log)
    {
        SYSTEMTIME st; GetLocalTime(&st);
        fprintf(g_log, "%02d:%02d:%02d.%03d %s\n", st.wHour, st.wMinute, st.wSecond, st.wMilliseconds, buf);
        fflush(g_log);
    }
    if (g_shm)
    {
        strncpy(g_shm->feederStatus, buf, sizeof g_shm->feederStatus - 1);
        g_shm->feederStatus[sizeof g_shm->feederStatus - 1] = 0;
    }
}


static void Store64(volatile uint64_t *p, uint64_t v) { InterlockedExchange64((volatile LONG64 *)p, (LONG64)v); }
static void Beat() { if (g_shm) Store64(&g_shm->feederHeartbeat, GetTickCount64()); }

static int Fail(const char *what)
{
    Status("FAILED: %s", what);
    if (g_shm) g_shm->feederFailed = 1;
    return 1;
}

// ---------------- shaders ----------------
// Compute: the shared frame (display-encoded) -> linear FP16 at the network's size; motion -> network pixels.
static const char *kDecodeCs = R"(
cbuffer C : register(b0) { float2 dstSize; float2 srcSize; uint decodeMode; uint hasMotion; float2 mvScale; float2 mvTexScale; float reactiveAmt; };
Texture2D<float4> src : register(t0);
Texture2D<float2> mv  : register(t1);
RWTexture2D<float4> fed : register(u0);
RWTexture2D<float2> mvOut : register(u1);
RWTexture2D<float> depthOut : register(u2);
RWTexture2D<float> reactiveOut : register(u3);
SamplerState lin : register(s0);
float3 SrgbToLinear(float3 c) { return c <= 0.04045 ? c / 12.92 : pow((c + 0.055) / 1.055, 2.4); }
[numthreads(8, 8, 1)]
void main(uint3 id : SV_DispatchThreadID)
{
    if (id.x >= (uint)dstSize.x || id.y >= (uint)dstSize.y) return;
    float2 uv = (float2(id.xy) + 0.5) / dstSize;
    float4 c = src.SampleLevel(lin, uv, 0);
    float3 l = decodeMode == 0 ? SrgbToLinear(saturate(c.rgb)) : max(c.rgb, 0);
    fed[id.xy] = float4(l, 1);
    float2 m = 0;
    if (hasMotion != 0)
    {
        // texture value * mvScale = displacement in motion-texture pixels; * mvTexScale = in network pixels
        m = mv.SampleLevel(lin, uv, 0) * mvScale * mvTexScale;
        if (any(isnan(m)) || any(abs(m) > 4096)) m = 0;
    }
    mvOut[id.xy] = m;     // always written: FSR reads it even without motion (then: no motion)
    depthOut[id.xy] = 0.5; // the game gives no depth; FSR gets a flat one
    reactiveOut[id.xy] = reactiveAmt; // how much FSR should trust this frame over its history (no depth to tell it)
}
)";

// Graphics: the shared output = original + (network answer - what it was fed), at full size.
static const char *kComposeVs = R"(
float4 main(uint id : SV_VertexID) : SV_Position
{
    float2 p = float2((id << 1) & 2, id & 2);
    return float4(p * float2(2, -2) + float2(-1, 1), 0, 1);
}
)";
static const char *kComposePs = R"(
cbuffer C : register(b0) { float2 size; uint decodeMode; float mixAmt; uint split; uint useFsr; float2 netUvScale; };
Texture2D<float4> orig : register(t0);
Texture2D<float4> net  : register(t1);
Texture2D<float4> fedT : register(t2);
Texture2D<float4> fsrT : register(t3);
SamplerState lin : register(s0);
float3 SrgbToLinear(float3 c) { return c <= 0.04045 ? c / 12.92 : pow((c + 0.055) / 1.055, 2.4); }
float3 LinearToSrgb(float3 c) { return c <= 0.0031308 ? c * 12.92 : 1.055 * pow(c, 1.0 / 2.4) - 0.055; }
float4 main(float4 pos : SV_Position) : SV_Target
{
    int2 p = int2(pos.xy);
    float4 o = orig.Load(int3(p, 0));
    float3 ol = decodeMode == 0 ? SrgbToLinear(saturate(o.rgb)) : o.rgb;
    float2 uv = pos.xy / size;
    float3 r;
    if (useFsr != 0)
        r = fsrT.Load(int3(p, 0)).rgb; // FSR 4 / 3: the network's answer reconstructed at full size
    else
    {
        // the network's allocation may be larger than what it answered for: uv * netUvScale
        float3 n = net.SampleLevel(lin, uv * netUvScale, 0).rgb;
        float3 f = fedT.SampleLevel(lin, uv, 0).rgb;
        r = ol + (n - f);
    }
    if (any(isnan(r))) r = ol;
    r = lerp(ol, r, mixAmt);
    if (split != 0)
    {
        float halfW = size.x * 0.5;
        if (pos.x < halfW) r = ol;
        if (abs(pos.x - halfW) < 1.0) r = float3(1, 1, 1);
    }
    r = decodeMode == 2 ? r : saturate(r);
    float3 e = decodeMode == 0 ? LinearToSrgb(r) : r;
    return float4(e, o.a);
}
)";

typedef HRESULT(WINAPI *PFN_Compile)(LPCVOID, SIZE_T, LPCSTR, const D3D_SHADER_MACRO *, ID3DInclude *, LPCSTR, LPCSTR, UINT,
                                     UINT, ID3DBlob **, ID3DBlob **);
static PFN_Compile g_compile = nullptr;

static bool Compile(const char *src, const char *target, Com<ID3DBlob> &out)
{
    Com<ID3DBlob> err;
    HRESULT hr = g_compile(src, strlen(src), "sh2nr", nullptr, nullptr, "main", target, D3DCOMPILE_OPTIMIZATION_LEVEL3, 0,
                           out.Put(), err.Put());
    if (FAILED(hr))
    {
        Status("shader compile (%s) failed: %s", target, err ? (const char *)err->GetBufferPointer() : "?");
        return false;
    }
    return true;
}

static DXGI_FORMAT ViewFormat(DXGI_FORMAT f)
{
    switch (f)
    {
    case DXGI_FORMAT_R8G8B8A8_TYPELESS: return DXGI_FORMAT_R8G8B8A8_UNORM;
    case DXGI_FORMAT_B8G8R8A8_TYPELESS: return DXGI_FORMAT_B8G8R8A8_UNORM;
    case DXGI_FORMAT_B8G8R8X8_TYPELESS: return DXGI_FORMAT_B8G8R8X8_UNORM;
    case DXGI_FORMAT_R10G10B10A2_TYPELESS: return DXGI_FORMAT_R10G10B10A2_UNORM;
    case DXGI_FORMAT_R16G16B16A16_TYPELESS: return DXGI_FORMAT_R16G16B16A16_FLOAT;
    case DXGI_FORMAT_R16G16_TYPELESS: return DXGI_FORMAT_R16G16_FLOAT;
    case DXGI_FORMAT_R32G32_TYPELESS: return DXGI_FORMAT_R32G32_FLOAT;
    default: return f;
    }
}
// 0 = display-encoded sRGB in a UNORM view (decode/encode in the shader), 1 = the view does it (_SRGB), 2 = linear float
static uint32_t DecodeMode(DXGI_FORMAT f)
{
    switch (f)
    {
    case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB: case DXGI_FORMAT_B8G8R8A8_UNORM_SRGB: case DXGI_FORMAT_B8G8R8X8_UNORM_SRGB: return 1;
    case DXGI_FORMAT_R16G16B16A16_FLOAT: case DXGI_FORMAT_R16G16B16A16_TYPELESS: return 2;
    default: return 0;
    }
}

static void Barrier(ID3D12GraphicsCommandList *cl, ID3D12Resource *r, D3D12_RESOURCE_STATES a, D3D12_RESOURCE_STATES b)
{
    if (a == b) return;
    D3D12_RESOURCE_BARRIER br = {};
    br.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    br.Transition.pResource = r;
    br.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
    br.Transition.StateBefore = a;
    br.Transition.StateAfter = b;
    cl->ResourceBarrier(1, &br);
}

struct Feeder
{
    std::wstring dir;
    DWORD pid = 0;
    HANDLE game = nullptr;

    Com<ID3D12Device> dev;
    Com<ID3D12CommandQueue> queue;
    Com<ID3D12CommandAllocator> allocA, allocB;
    Com<ID3D12GraphicsCommandList> listA, listB;
    Com<ID3D12Fence> idle;
    UINT64 idleValue = 0;
    HANDLE idleEvent = nullptr, inEvent = nullptr;

    Com<ID3D12RootSignature> csRoot, psRoot;
    Com<ID3D12PipelineState> csPso, psPso;
    DXGI_FORMAT psFormat = DXGI_FORMAT_UNKNOWN;
    Com<ID3D12DescriptorHeap> heap, rtvHeap;
    UINT descSize = 0;

    // per generation
    uint32_t gen = 0;
    Com<ID3D12Resource> inTex, outTex, mvTex, fed, mvFed, depthFed, reactiveFed, fsrOut;
    Com<ID3D12Fence> fin, fout;
    UINT w = 0, h = 0, nw = 0, nh = 0;
    DXGI_FORMAT fmt = DXGI_FORMAT_UNKNOWN;
    bool motion = false;
    bool historyValid = false;
    uint32_t netCap = 0;

    // FSR (AMD FidelityFX API)
    HMODULE ffxDll = nullptr;
    PfnFfxCreateContext ffxCreate = nullptr;
    PfnFfxDestroyContext ffxDestroy = nullptr;
    PfnFfxDispatch ffxDispatchFn = nullptr;
    PfnFfxQuery ffxQueryFn = nullptr;
    ffxContext fsrCtx = nullptr;
    bool fsrOn = false;                  // this generation upscales with FSR
    bool fsrUnavailable = false;         // the DLLs are missing or refused: native composition from now on
    uint32_t fsrModeUsed = 0, fsrQualityUsed = 0, fsrVersionUsed = 0; // what the generation was built with
    std::string fsrName;
    std::chrono::steady_clock::time_point lastFrame = std::chrono::steady_clock::now();

    // runtime
    HMODULE rtDll = nullptr;
    LmxxfNrApi api = {};
    void *ctx = nullptr;
    uint32_t maxW = 1920, maxH = 1080;
    uint64_t frames = 0;

    std::string RtError()
    {
        char b[512] = {};
        if (api.GetLastError) api.GetLastError(b, sizeof b);
        return b;
    }

    bool InitDevice()
    {
        LUID luid;
        luid.LowPart = g_shm->luidLow;
        luid.HighPart = g_shm->luidHigh;
        Com<IDXGIFactory4> fac;
        if (FAILED(CreateDXGIFactory1(__uuidof(IDXGIFactory4), (void **)fac.Put())))
            return Fail("CreateDXGIFactory1"), false;
        Com<IDXGIAdapter1> ad;
        if (FAILED(fac->EnumAdapterByLuid(luid, __uuidof(IDXGIAdapter1), (void **)ad.Put())))
            return Fail("the game's adapter was not found by LUID"), false;
        DXGI_ADAPTER_DESC1 ad1;
        ad->GetDesc1(&ad1);
        char an[128];
        WideCharToMultiByte(CP_UTF8, 0, ad1.Description, -1, an, 128, nullptr, nullptr);
        if (FAILED(D3D12CreateDevice(ad.Get(), D3D_FEATURE_LEVEL_11_0, __uuidof(ID3D12Device), (void **)dev.Put())))
            return Fail("D3D12CreateDevice"), false;
        Status("D3D12 device on %s (vendor 0x%04x)", an, ad1.VendorId);
        if (ad1.VendorId != 0x1002)
            Status("warning: the adapter is not AMD - the neural runtime will not start");

        D3D12_COMMAND_QUEUE_DESC qd = {};
        qd.Type = D3D12_COMMAND_LIST_TYPE_DIRECT;
        if (FAILED(dev->CreateCommandQueue(&qd, __uuidof(ID3D12CommandQueue), (void **)queue.Put())))
            return Fail("CreateCommandQueue"), false;
        dev->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, __uuidof(ID3D12CommandAllocator), (void **)allocA.Put());
        dev->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, __uuidof(ID3D12CommandAllocator), (void **)allocB.Put());
        dev->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, allocA.Get(), nullptr, __uuidof(ID3D12GraphicsCommandList), (void **)listA.Put());
        dev->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, allocB.Get(), nullptr, __uuidof(ID3D12GraphicsCommandList), (void **)listB.Put());
        if (!listA || !listB) return Fail("CreateCommandList"), false;
        listA->Close();
        listB->Close();
        dev->CreateFence(0, D3D12_FENCE_FLAG_NONE, __uuidof(ID3D12Fence), (void **)idle.Put());
        idleEvent = CreateEventW(nullptr, FALSE, FALSE, nullptr);
        inEvent = CreateEventW(nullptr, FALSE, FALSE, nullptr);

        D3D12_DESCRIPTOR_HEAP_DESC hd = {};
        hd.Type = D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV;
        hd.NumDescriptors = 16;
        hd.Flags = D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
        dev->CreateDescriptorHeap(&hd, __uuidof(ID3D12DescriptorHeap), (void **)heap.Put());
        D3D12_DESCRIPTOR_HEAP_DESC rd = {};
        rd.Type = D3D12_DESCRIPTOR_HEAP_TYPE_RTV;
        rd.NumDescriptors = 1;
        dev->CreateDescriptorHeap(&rd, __uuidof(ID3D12DescriptorHeap), (void **)rtvHeap.Put());
        descSize = dev->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);
        return heap && rtvHeap;
    }

    bool MakeRoot(bool compute, Com<ID3D12RootSignature> &out)
    {
        D3D12_DESCRIPTOR_RANGE ranges[2] = {};
        ranges[0].RangeType = D3D12_DESCRIPTOR_RANGE_TYPE_SRV;
        ranges[0].NumDescriptors = compute ? 2 : 4;
        ranges[0].OffsetInDescriptorsFromTableStart = 0;
        ranges[1].RangeType = D3D12_DESCRIPTOR_RANGE_TYPE_UAV;
        ranges[1].NumDescriptors = 4;
        ranges[1].OffsetInDescriptorsFromTableStart = 2;
        D3D12_ROOT_PARAMETER params[2] = {};
        params[0].ParameterType = D3D12_ROOT_PARAMETER_TYPE_DESCRIPTOR_TABLE;
        params[0].DescriptorTable.NumDescriptorRanges = compute ? 2 : 1;
        params[0].DescriptorTable.pDescriptorRanges = ranges;
        params[0].ShaderVisibility = D3D12_SHADER_VISIBILITY_ALL;
        params[1].ParameterType = D3D12_ROOT_PARAMETER_TYPE_32BIT_CONSTANTS;
        params[1].Constants.Num32BitValues = 16;
        params[1].ShaderVisibility = D3D12_SHADER_VISIBILITY_ALL;
        D3D12_STATIC_SAMPLER_DESC s = {};
        s.Filter = D3D12_FILTER_MIN_MAG_MIP_LINEAR;
        s.AddressU = s.AddressV = s.AddressW = D3D12_TEXTURE_ADDRESS_MODE_CLAMP;
        s.MaxLOD = D3D12_FLOAT32_MAX;
        s.ShaderVisibility = D3D12_SHADER_VISIBILITY_ALL;
        D3D12_ROOT_SIGNATURE_DESC rs = {};
        rs.NumParameters = 2;
        rs.pParameters = params;
        rs.NumStaticSamplers = 1;
        rs.pStaticSamplers = &s;
        Com<ID3DBlob> blob, err;
        if (FAILED(D3D12SerializeRootSignature(&rs, D3D_ROOT_SIGNATURE_VERSION_1, blob.Put(), err.Put())))
            return Status("root signature: %s", err ? (const char *)err->GetBufferPointer() : "?"), false;
        return SUCCEEDED(dev->CreateRootSignature(0, blob->GetBufferPointer(), blob->GetBufferSize(), __uuidof(ID3D12RootSignature),
                                                   (void **)out.Put()));
    }

    bool InitShaders()
    {
        HMODULE dc = LoadLibraryW(L"d3dcompiler_47.dll");
        if (dc) g_compile = (PFN_Compile)GetProcAddress(dc, "D3DCompile");
        if (!g_compile) return Fail("d3dcompiler_47.dll not found"), false;
        Com<ID3DBlob> cs;
        if (!Compile(kDecodeCs, "cs_5_0", cs)) return Fail("decode shader"), false;
        if (!MakeRoot(true, csRoot) || !MakeRoot(false, psRoot)) return Fail("root signatures"), false;
        D3D12_COMPUTE_PIPELINE_STATE_DESC cd = {};
        cd.pRootSignature = csRoot.Get();
        cd.CS = { cs->GetBufferPointer(), cs->GetBufferSize() };
        if (FAILED(dev->CreateComputePipelineState(&cd, __uuidof(ID3D12PipelineState), (void **)csPso.Put())))
            return Fail("compute PSO"), false;
        return true;
    }

    bool EnsurePs(DXGI_FORMAT rtvFmt)
    {
        if (psPso && psFormat == rtvFmt) return true;
        Com<ID3DBlob> vs, ps;
        if (!Compile(kComposeVs, "vs_5_0", vs) || !Compile(kComposePs, "ps_5_0", ps)) return false;
        D3D12_GRAPHICS_PIPELINE_STATE_DESC gd = {};
        gd.pRootSignature = psRoot.Get();
        gd.VS = { vs->GetBufferPointer(), vs->GetBufferSize() };
        gd.PS = { ps->GetBufferPointer(), ps->GetBufferSize() };
        gd.BlendState.RenderTarget[0].RenderTargetWriteMask = D3D12_COLOR_WRITE_ENABLE_ALL;
        gd.SampleMask = 0xffffffffu;
        gd.RasterizerState.FillMode = D3D12_FILL_MODE_SOLID;
        gd.RasterizerState.CullMode = D3D12_CULL_MODE_NONE;
        gd.RasterizerState.DepthClipEnable = TRUE;
        gd.PrimitiveTopologyType = D3D12_PRIMITIVE_TOPOLOGY_TYPE_TRIANGLE;
        gd.NumRenderTargets = 1;
        gd.RTVFormats[0] = rtvFmt;
        gd.SampleDesc.Count = 1;
        psPso.Reset();
        if (FAILED(dev->CreateGraphicsPipelineState(&gd, __uuidof(ID3D12PipelineState), (void **)psPso.Put())))
            return Status("graphics PSO for format %u failed", rtvFmt), false;
        psFormat = rtvFmt;
        return true;
    }

    bool InitRuntime()
    {
        std::wstring dll = dir + L"LmxxfNrRuntime.dll";
        std::wstring pak = dir + L"LmxxfNrRuntime.pak";
        SetDllDirectoryW(dir.c_str());
        rtDll = LoadLibraryW(dll.c_str());
        if (!rtDll) { Status("LmxxfNrRuntime.dll failed to load (error %lu)", GetLastError()); return Fail("runtime DLL"), false; }
        auto getApi = (int32_t(*)(uint32_t, LmxxfNrApi *))GetProcAddress(rtDll, "LmxxfNrGetApi");
        api = {};
        api.struct_size = sizeof api;
        if (!getApi || getApi(LMXXF_NR_ABI_VERSION, &api) != LMXXF_NR_OK || !api.EnqueueHipAsync || !api.OutputReady || !api.AbandonJob)
            return Fail("LmxxfNrGetApi refused this host (runtime too old or too new)"), false;
        LmxxfNrCapabilities caps = {};
        caps.struct_size = sizeof caps;
        if (api.QueryCapabilities && api.QueryCapabilities(&caps) == LMXXF_NR_OK && caps.max_input_width && caps.max_input_height)
        {
            maxW = caps.max_input_width;
            maxH = caps.max_input_height;
        }
        LmxxfNrCreateInfo ci = {};
        ci.struct_size = sizeof ci;
        ci.device = dev.Get();
        ci.queue = queue.Get();
        ci.assets_directory = pak.c_str();
        if (api.Create(&ci, &ctx) != LMXXF_NR_OK || !ctx)
        {
            Status("runtime Create failed: %s", RtError().c_str());
            return Fail("runtime Create"), false;
        }
        if (api.PrepareSession(ctx) != LMXXF_NR_OK)
        {
            Status("runtime PrepareSession failed: %s", RtError().c_str());
            return Fail("runtime PrepareSession"), false;
        }
        char st[512] = {};
        if (api.GetStatus) api.GetStatus(ctx, st, sizeof st);
        Status("lmxxf runtime up (network input ceiling %ux%u) %s", maxW, maxH, st);
        return true;
    }

    template <class T> bool OpenNamed(const wchar_t *fmtStr, unsigned long a, unsigned long b, Com<T> &out)
    {
        wchar_t name[128];
        swprintf(name, 128, fmtStr, a, b);
        HANDLE hnd = nullptr;
        HRESULT hr = dev->OpenSharedHandleByName(name, GENERIC_ALL, &hnd);
        if (FAILED(hr)) { Status("OpenSharedHandleByName(%ls) failed 0x%08lx", name, hr); return false; }
        hr = dev->OpenSharedHandle(hnd, __uuidof(T), (void **)out.Put());
        CloseHandle(hnd);
        if (FAILED(hr)) { Status("OpenSharedHandle(%ls) failed 0x%08lx", name, hr); return false; }
        return true;
    }

    Com<ID3D12Resource> Tex(UINT tw, UINT th, DXGI_FORMAT f)
    {
        Com<ID3D12Resource> r;
        D3D12_HEAP_PROPERTIES hp = {};
        hp.Type = D3D12_HEAP_TYPE_DEFAULT;
        D3D12_RESOURCE_DESC d = {};
        d.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D;
        d.Width = tw; d.Height = th; d.DepthOrArraySize = 1; d.MipLevels = 1; d.Format = f;
        d.SampleDesc.Count = 1;
        d.Flags = D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS;
        dev->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &d, D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE, nullptr,
                                     __uuidof(ID3D12Resource), (void **)r.Put());
        return r;
    }

    static void FfxMessage(uint32_t type, const wchar_t *msg)
    {
        char m[512];
        WideCharToMultiByte(CP_UTF8, 0, msg, -1, m, sizeof m, nullptr, nullptr);
        Status("FSR %s: %s", type == FFX_API_MESSAGE_TYPE_ERROR ? "error" : "warning", m);
    }

    bool LoadFfx()
    {
        if (ffxDll) return true;
        if (fsrUnavailable) return false;
        const std::wstring path = dir + L"amd_fidelityfx_loader_dx12.dll";
        ffxDll = LoadLibraryW(path.c_str());
        if (!ffxDll)
        {
            Status("FSR: amd_fidelityfx_loader_dx12.dll not found or not loadable (error %lu) - using the native path", GetLastError());
            fsrUnavailable = true;
            return false;
        }
        ffxCreate = (PfnFfxCreateContext)GetProcAddress(ffxDll, "ffxCreateContext");
        ffxDestroy = (PfnFfxDestroyContext)GetProcAddress(ffxDll, "ffxDestroyContext");
        ffxDispatchFn = (PfnFfxDispatch)GetProcAddress(ffxDll, "ffxDispatch");
        ffxQueryFn = (PfnFfxQuery)GetProcAddress(ffxDll, "ffxQuery");
        if (!ffxCreate || !ffxDestroy || !ffxDispatchFn || !ffxQueryFn)
        {
            Status("FSR: the loader DLL lacks the FidelityFX API exports - using the native path");
            fsrUnavailable = true;
            return false;
        }
        return true;
    }

    void DestroyFsr()
    {
        if (fsrCtx && ffxDestroy) ffxDestroy(&fsrCtx, nullptr);
        fsrCtx = nullptr;
    }

    // Lists the upscaler versions the DLL offers on this device and picks one: wanted 4 / 3 = newest of that
    // major version, 0 = no override (the API's own choice: the newest the card supports).
    uint64_t PickFsrVersion(uint32_t wanted)
    {
        uint64_t count = 0;
        ffxQueryDescGetVersions q = {};
        q.header.type = FFX_API_QUERY_DESC_TYPE_GET_VERSIONS;
        q.createDescType = FFX_API_CREATE_CONTEXT_DESC_TYPE_UPSCALE;
        q.device = dev.Get();
        q.outputCount = &count;
        if (ffxQueryFn(nullptr, &q.header) != FFX_API_RETURN_OK || count == 0) return 0;
        std::vector<uint64_t> ids(count);
        std::vector<const char *> names(count);
        q.versionIds = ids.data();
        q.versionNames = names.data();
        if (ffxQueryFn(nullptr, &q.header) != FFX_API_RETURN_OK) return 0;
        std::string list;
        uint64_t pick = 0;
        for (uint64_t i = 0; i < count; ++i)
        {
            const char *n = names[i] ? names[i] : "?";
            list += (i ? ", " : "") + std::string(n);
            if (wanted && !pick && n[0] == char('0' + wanted)) pick = ids[i]; // the list is newest first
        }
        Status("FSR: versions offered on this card: %s", list.c_str());
        if (wanted && !pick) Status("FSR: FSR %u is not offered here - using the default", wanted);
        return pick;
    }

    bool CreateFsr(UINT rw, UINT rh, UINT dw, UINT dh, uint32_t wantedVersion)
    {
        DestroyFsr();
        if (!LoadFfx()) return false;
        ffxCreateBackendDX12Desc backend = {};
        backend.header.type = FFX_API_CREATE_CONTEXT_DESC_TYPE_BACKEND_DX12;
        backend.device = dev.Get();
        ffxOverrideVersion over = {};
        over.header.type = FFX_API_DESC_TYPE_OVERRIDE_VERSION;
        over.versionId = PickFsrVersion(wantedVersion);
        if (over.versionId) backend.header.pNext = &over.header;
        ffxCreateContextDescUpscale cd = {};
        cd.header.type = FFX_API_CREATE_CONTEXT_DESC_TYPE_UPSCALE;
        cd.header.pNext = &backend.header;
        cd.flags = 0; // linear SDR colour, motion vectors at render resolution, no jitter
        cd.maxRenderSize = { rw, rh };
        cd.maxUpscaleSize = { dw, dh };
        cd.fpMessage = &FfxMessage;
        const ffxReturnCode_t rc = ffxCreate(&fsrCtx, &cd.header, nullptr);
        if (rc != FFX_API_RETURN_OK || !fsrCtx)
        {
            Status("FSR: ffxCreateContext failed (%u) - using the native path", rc);
            fsrCtx = nullptr;
            return false;
        }
        ffxQueryGetProviderVersion pv = {};
        pv.header.type = FFX_API_QUERY_DESC_TYPE_GET_PROVIDER_VERSION;
        fsrName = (ffxQueryFn(&fsrCtx, &pv.header) == FFX_API_RETURN_OK && pv.versionName) ? pv.versionName : "?";
        return true;
    }

    bool OpenGeneration(uint32_t g)
    {
        DestroyFsr();
        inTex.Reset(); outTex.Reset(); mvTex.Reset(); fed.Reset(); mvFed.Reset(); depthFed.Reset(); reactiveFed.Reset(); fsrOut.Reset(); fin.Reset(); fout.Reset();
        const unsigned long p = pid;
        if (!OpenNamed(SH2NR_TEX_IN_FMT, p, g, inTex) || !OpenNamed(SH2NR_TEX_OUT_FMT, p, g, outTex)) return false;
        const unsigned long fg = g_shm->fenceGen;
        if (!OpenNamed(SH2NR_FENCE_IN_FMT, p, fg, fin) || !OpenNamed(SH2NR_FENCE_OUT_FMT, p, fg, fout)) return false;
        w = g_shm->width; h = g_shm->height; fmt = (DXGI_FORMAT)g_shm->dxgiFormat;
        motion = g_shm->hasMotion != 0 && OpenNamed(SH2NR_TEX_MV_FMT, p, g, mvTex);
        // The network's size: the frame itself when it fits under the ceiling, else scaled down to fit.
        UINT capH = maxH, capW = maxW;
        netCap = g_shm->networkHeight;
        if (netCap >= 360 && netCap < maxH) { capH = netCap; capW = UINT(double(maxW) * netCap / maxH); }
        // With FSR the network runs at the FSR quality mode's render size (and never above its own ceiling);
        // FSR then rebuilds the full frame from the network's answer.
        fsrModeUsed = g_shm->upscaler; fsrQualityUsed = g_shm->fsrQuality; fsrVersionUsed = g_shm->fsrVersion;
        const bool wantFsr = fsrModeUsed == 1 && !fsrUnavailable;
        static const double kRatio[5] = { 1.0, 1.5, 1.7, 2.0, 3.0 };
        const double ratio = wantFsr ? kRatio[std::min<uint32_t>(fsrQualityUsed, 4u)] : 1.0;
        const double s = std::min(1.0 / ratio, std::min(double(capW) / w, double(capH) / h));
        nw = std::max(64u, UINT(w * s)) & ~1u;
        nh = std::max(64u, UINT(h * s)) & ~1u;
        fed = Tex(nw, nh, DXGI_FORMAT_R16G16B16A16_FLOAT);
        mvFed = Tex(nw, nh, DXGI_FORMAT_R16G16_FLOAT);
        depthFed = Tex(nw, nh, DXGI_FORMAT_R32_FLOAT);
        reactiveFed = Tex(nw, nh, DXGI_FORMAT_R8_UNORM);
        if (!fed || !mvFed || !depthFed || !reactiveFed) return Status("could not create the network's textures"), false;
        fsrOn = false;
        snprintf(g_shm->upscalerStatus, sizeof g_shm->upscalerStatus, "native");
        if (wantFsr)
        {
            fsrOut = Tex(w, h, DXGI_FORMAT_R16G16B16A16_FLOAT);
            fsrOn = fsrOut && CreateFsr(nw, nh, w, h, fsrVersionUsed);
            if (fsrOn)
            {
                snprintf(g_shm->upscalerStatus, sizeof g_shm->upscalerStatus, "FSR %s, %ux%u -> %ux%u", fsrName.c_str(), nw, nh, w, h);
                Status("FSR up: %s (network %ux%u -> display %ux%u)", fsrName.c_str(), nw, nh, w, h);
            }
            else if (!fsrUnavailable)
                fsrUnavailable = true; // do not retry every generation; native from here on
        }
        if (!EnsurePs(ViewFormat(fmt))) return false;
        g_shm->netWidth = nw; g_shm->netHeight = nh;
        gen = g;
        historyValid = false;
        Status("generation %u: frame %ux%u (format %u), network %ux%u, motion %s, upscaler %s", g, w, h, fmt, nw, nh,
               motion ? "yes" : "no", fsrOn ? "FSR" : "native");
        return true;
    }

    void WaitIdle()
    {
        ++idleValue;
        queue->Signal(idle.Get(), idleValue);
        if (idle->GetCompletedValue() < idleValue)
        {
            idle->SetEventOnCompletion(idleValue, idleEvent);
            WaitForSingleObject(idleEvent, 5000);
        }
    }

    D3D12_CPU_DESCRIPTOR_HANDLE Cpu(UINT i) { auto hnd = heap->GetCPUDescriptorHandleForHeapStart(); hnd.ptr += SIZE_T(i) * descSize; return hnd; }
    D3D12_GPU_DESCRIPTOR_HANDLE Gpu(UINT i) { auto hnd = heap->GetGPUDescriptorHandleForHeapStart(); hnd.ptr += UINT64(i) * descSize; return hnd; }

    void Srv(UINT slot, ID3D12Resource *r, DXGI_FORMAT f)
    {
        D3D12_SHADER_RESOURCE_VIEW_DESC d = {};
        d.Format = f;
        d.ViewDimension = D3D12_SRV_DIMENSION_TEXTURE2D;
        d.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
        d.Texture2D.MipLevels = 1;
        dev->CreateShaderResourceView(r, &d, Cpu(slot));
    }
    void Uav(UINT slot, ID3D12Resource *r, DXGI_FORMAT f)
    {
        D3D12_UNORDERED_ACCESS_VIEW_DESC d = {};
        d.Format = f;
        d.ViewDimension = D3D12_UAV_DIMENSION_TEXTURE2D;
        dev->CreateUnorderedAccessView(r, nullptr, &d, Cpu(slot));
    }

    // One frame, synchronous: decode -> network -> compose -> signal the out-fence with `value`.
    bool Process(uint64_t value)
    {
        const auto t0 = std::chrono::steady_clock::now();
        const bool useMv = motion && g_shm->useMotion;
        const DXGI_FORMAT vf = ViewFormat(fmt);
        const uint32_t decodeMode = DecodeMode(fmt);
        const D3D12_RESOURCE_STATES kSrv = D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE;
        const D3D12_RESOURCE_STATES kBoth = D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE | D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
        const D3D12_RESOURCE_STATES kCommon = D3D12_RESOURCE_STATE_COMMON;

        // ---- list A: decode + network inputs ----
        allocA->Reset();
        listA->Reset(allocA.Get(), nullptr);
        ID3D12DescriptorHeap *heaps[] = { heap.Get() };
        listA->SetDescriptorHeaps(1, heaps);
        // slots 0..3: decode table (src, mv, fed UAV, mvFed UAV)
        Srv(0, inTex.Get(), vf);
        if (useMv) Srv(1, mvTex.Get(), ViewFormat((DXGI_FORMAT)g_shm->mvFormat));
        else Srv(1, nullptr, DXGI_FORMAT_R16G16_FLOAT);
        Uav(2, fed.Get(), DXGI_FORMAT_R16G16B16A16_FLOAT);
        Uav(3, mvFed.Get(), DXGI_FORMAT_R16G16_FLOAT);
        Uav(4, depthFed.Get(), DXGI_FORMAT_R32_FLOAT);
        Uav(5, reactiveFed.Get(), DXGI_FORMAT_R8_UNORM);
        Barrier(listA.Get(), inTex.Get(), kCommon, kSrv);
        if (useMv) Barrier(listA.Get(), mvTex.Get(), kCommon, kSrv);
        Barrier(listA.Get(), fed.Get(), kSrv, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        Barrier(listA.Get(), mvFed.Get(), kSrv, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        Barrier(listA.Get(), depthFed.Get(), kSrv, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        Barrier(listA.Get(), reactiveFed.Get(), kSrv, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
        listA->SetComputeRootSignature(csRoot.Get());
        listA->SetPipelineState(csPso.Get());
        listA->SetComputeRootDescriptorTable(0, Gpu(0));
        struct { float dw, dh, sw, sh; uint32_t mode, hasMv; float msx, msy, tsx, tsy; float reactive; uint32_t pad[5]; } c = {};
        c.reactive = std::clamp(g_shm->fsrReactive, 0.f, 1.f);
        c.dw = float(nw); c.dh = float(nh); c.sw = float(w); c.sh = float(h);
        c.mode = decodeMode; c.hasMv = useMv ? 1u : 0u;
        c.msx = g_shm->mvScaleX; c.msy = g_shm->mvScaleY;
        c.tsx = g_shm->mvWidth ? float(nw) / float(g_shm->mvWidth) : 1.f;
        c.tsy = g_shm->mvHeight ? float(nh) / float(g_shm->mvHeight) : 1.f;
        // mvScale is in texture-size pixels (UV * size); convert UV -> motion-texture pixels -> network pixels
        listA->SetComputeRoot32BitConstants(1, 16, &c, 0);
        listA->Dispatch((nw + 7) / 8, (nh + 7) / 8, 1);
        Barrier(listA.Get(), fed.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, kSrv);
        Barrier(listA.Get(), mvFed.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, kSrv);
        Barrier(listA.Get(), depthFed.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, kSrv);
        Barrier(listA.Get(), reactiveFed.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, kSrv);
        if (useMv) Barrier(listA.Get(), mvTex.Get(), kSrv, kCommon);

        bool reset = !historyValid;
        if (g_shm->historyReset) { g_shm->historyReset = 0; reset = true; }
        LmxxfNrFrameInfo fi = {};
        fi.struct_size = 128; // the size every runtime since AMDNR 0.3.3.2 accepts (no character controls)
        fi.session_id = 1;
        fi.frame_id = ++frames;
        fi.list_generation = frames;
        fi.command_list = listA.Get();
        fi.color_width = nw;
        fi.color_height = nh;
        fi.color = fed.Get();
        fi.color_state = kSrv;
        fi.flags = LMXXF_NR_FRAME_FLAG_STRENGTH | (useMv ? LMXXF_NR_FRAME_FLAG_TEMPORAL : 0u) |
                   (g_shm->fullNetwork ? LMXXF_NR_FRAME_FLAG_FULL_NETWORK : 0u);
        fi.transfer_strength = std::clamp(g_shm->detailStrength, 0.f, 1.f);
        fi.color_strength = std::clamp(g_shm->colorStrength, 0.f, 1.f);
        fi.model_scale = 1.f;
        if (useMv)
        {
            fi.motion = mvFed.Get();
            fi.motion_state = kSrv;
            fi.motion_width = nw;
            fi.motion_height = nh;
            fi.motion_scale_x = 1.f;
            fi.motion_scale_y = 1.f;
            fi.history_reset = reset ? 1u : 0u;
            fi.output_smooth = std::clamp(g_shm->outputSmooth, 0.f, 0.8f);
            fi.output_smooth_threshold = 6.f / 255.f;
        }
        fi.passes = std::clamp<uint32_t>(g_shm->passes, 1u, 3u);
        // lmxxf's character mask controls (AMDNR's NrControls policy, mask on): tone 1, structure 1,
        // skin = character structure, other = scene structure, style 1. The built-in values send the 128-byte
        // frame with no flag, exactly as AMDNR does.
        {
            auto clampCtl = [](float v) { return std::isfinite(v) ? std::clamp(v, 0.f, 4.f) : 1.f; };
            const float skin = clampCtl(g_shm->characterStructure);
            const float other = clampCtl(g_shm->sceneStructure);
            if (skin != 1.f || other != 1.f)
            {
                fi.struct_size = sizeof fi;
                fi.flags |= LMXXF_NR_FRAME_FLAG_CONTROLS;
                fi.control_tone = 1.f;
                fi.control_structure = 1.f;
                fi.control_skin = skin;
                fi.control_other = other;
                fi.control_style = 1.f;
            }
        }
        LmxxfNrJob job = {};
        job.struct_size = sizeof job;
        int32_t rc = api.PrepareFrame(ctx, &fi, &job);
        if (rc == LMXXF_NR_OK)
            rc = api.RecordInputs(ctx, job.handle, listA.Get());
        Barrier(listA.Get(), inTex.Get(), kSrv, kCommon);
        listA->Close();
        if (rc != LMXXF_NR_OK)
        {
            Status("PrepareFrame/RecordInputs failed (%d): %s", rc, RtError().c_str());
            if (job.handle) api.CancelUnsubmitted(ctx, job.handle);
            ID3D12CommandList *l[] = { listA.Get() };
            queue->ExecuteCommandLists(1, l);
            WaitIdle();
            return false;
        }
        {
            ID3D12CommandList *l[] = { listA.Get() };
            queue->ExecuteCommandLists(1, l);
        }
        // AMDNR's own path: launch without a queue wait, then wait for the answer on the CPU (bounded);
        // RecordOutputs below puts the queue wait on the HIP fence, which is then already signalled.
        rc = api.EnqueueHipAsync(ctx, job.handle, queue.Get());
        if (rc != LMXXF_NR_OK)
        {
            Status("EnqueueHipAsync failed (%d): %s", rc, RtError().c_str());
            api.AbandonJob(ctx, job.handle);
            WaitIdle();
            return false;
        }
        {
            const auto tw = std::chrono::steady_clock::now();
            uint32_t ready = 0;
            while (api.OutputReady(ctx, job.handle, &ready) == LMXXF_NR_OK && ready == 0u)
            {
                if (std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - tw).count() > 2000.0)
                {
                    Status("the network's answer did not arrive within 2000 ms");
                    api.AbandonJob(ctx, job.handle);
                    WaitIdle();
                    return false;
                }
                Beat();
                Sleep(0);
            }
        }

        // ---- list B: network outputs + compose into the shared output ----
        allocB->Reset();
        listB->Reset(allocB.Get(), nullptr);
        rc = api.RecordOutputs(ctx, job.handle, listB.Get());
        listB->SetDescriptorHeaps(1, heaps); // after the runtime's own recording, which may bind its heaps
        auto *net = static_cast<ID3D12Resource *>(job.private_output);
        api.Retire(ctx, job.handle);
        if (rc != LMXXF_NR_OK || !net)
        {
            Status("RecordOutputs failed (%d): %s", rc, RtError().c_str());
            listB->Close();
            ID3D12CommandList *l[] = { listB.Get() };
            queue->ExecuteCommandLists(1, l);
            WaitIdle();
            return false;
        }
        const D3D12_RESOURCE_DESC netDesc = net->GetDesc();
        const DXGI_FORMAT netFmt = netDesc.Format == DXGI_FORMAT_R16G16B16A16_TYPELESS ? DXGI_FORMAT_R16G16B16A16_FLOAT : ViewFormat(netDesc.Format);
        // ---- FSR: the network's answer (render size) -> the full frame ----
        bool fsrRan = false;
        if (fsrOn && fsrCtx)
        {
            const auto now = std::chrono::steady_clock::now();
            float dt = std::chrono::duration<float, std::milli>(now - lastFrame).count();
            if (!(dt > 0.f && dt < 1000.f)) dt = 16.7f;
            Barrier(listB.Get(), fsrOut.Get(), kSrv, D3D12_RESOURCE_STATE_UNORDERED_ACCESS);
            ffxDispatchDescUpscale d = {};
            d.header.type = FFX_API_DISPATCH_DESC_TYPE_UPSCALE;
            d.commandList = listB.Get();
            d.color = ffxApiGetResourceDX12(net, FFX_API_RESOURCE_STATE_COMPUTE_READ);
            d.depth = ffxApiGetResourceDX12(depthFed.Get(), FFX_API_RESOURCE_STATE_COMPUTE_READ);
            d.motionVectors = ffxApiGetResourceDX12(mvFed.Get(), FFX_API_RESOURCE_STATE_COMPUTE_READ);
            d.reactive = ffxApiGetResourceDX12(reactiveFed.Get(), FFX_API_RESOURCE_STATE_COMPUTE_READ);
            d.output = ffxApiGetResourceDX12(fsrOut.Get(), FFX_API_RESOURCE_STATE_UNORDERED_ACCESS, FFX_API_RESOURCE_USAGE_UAV);
            d.jitterOffset = { 0.f, 0.f };            // the game has no jitter
            d.motionVectorScale = { 1.f, 1.f };       // mvFed is in render pixels, pointing to the previous frame
            d.renderSize = { nw, nh };
            d.upscaleSize = { w, h };
            d.enableSharpening = g_shm->fsrSharpness > 0.f;
            d.sharpness = std::clamp(g_shm->fsrSharpness, 0.f, 1.f);
            d.frameTimeDelta = dt;
            d.preExposure = 1.f;
            d.reset = reset;
            d.cameraNear = 0.1f;
            d.cameraFar = 1000.f;
            d.cameraFovAngleVertical = 1.0472f;
            d.viewSpaceToMetersFactor = 1.f;
            d.flags = 0;
            const ffxReturnCode_t frc = ffxDispatchFn(&fsrCtx, &d.header);
            Barrier(listB.Get(), fsrOut.Get(), D3D12_RESOURCE_STATE_UNORDERED_ACCESS, kSrv);
            if (frc == FFX_API_RETURN_OK)
                fsrRan = true;
            else
                Status("FSR: dispatch failed (%u) - this frame uses the native path", frc);
            listB->SetDescriptorHeaps(1, heaps); // FSR binds its own heaps
        }
        lastFrame = std::chrono::steady_clock::now();
        // slots 8..11: compose table (orig, net, fed, fsr)
        Srv(8, inTex.Get(), vf);
        Srv(9, net, netFmt);
        Srv(10, fed.Get(), DXGI_FORMAT_R16G16B16A16_FLOAT);
        Srv(11, fsrRan ? fsrOut.Get() : nullptr, DXGI_FORMAT_R16G16B16A16_FLOAT);
        D3D12_RENDER_TARGET_VIEW_DESC rv = {};
        rv.Format = vf;
        rv.ViewDimension = D3D12_RTV_DIMENSION_TEXTURE2D;
        auto rtv = rtvHeap->GetCPUDescriptorHandleForHeapStart();
        dev->CreateRenderTargetView(outTex.Get(), &rv, rtv);
        Barrier(listB.Get(), inTex.Get(), kCommon, kBoth);
        Barrier(listB.Get(), net, kSrv, kBoth);
        Barrier(listB.Get(), fed.Get(), kSrv, kBoth);
        if (fsrRan) Barrier(listB.Get(), fsrOut.Get(), kSrv, kBoth);
        Barrier(listB.Get(), outTex.Get(), kCommon, D3D12_RESOURCE_STATE_RENDER_TARGET);
        listB->SetGraphicsRootSignature(psRoot.Get());
        listB->SetPipelineState(psPso.Get());
        listB->SetGraphicsRootDescriptorTable(0, Gpu(8));
        struct { float sw, sh; uint32_t mode; float mix; uint32_t split, useFsr; float nus, nvs; } pc = {};
        pc.sw = float(w); pc.sh = float(h); pc.mode = decodeMode;
        pc.mix = std::clamp(g_shm->mix, 0.f, 1.f);
        pc.split = g_shm->splitView;
        pc.useFsr = fsrRan ? 1u : 0u;
        // the runtime's answer may sit in a larger allocation than the size it answered for
        pc.nus = float(nw) / float(netDesc.Width);
        pc.nvs = float(nh) / float(netDesc.Height);
        listB->SetGraphicsRoot32BitConstants(1, 8, &pc, 0);
        D3D12_VIEWPORT vp = { 0, 0, float(w), float(h), 0, 1 };
        D3D12_RECT sc = { 0, 0, LONG(w), LONG(h) };
        listB->RSSetViewports(1, &vp);
        listB->RSSetScissorRects(1, &sc);
        listB->OMSetRenderTargets(1, &rtv, FALSE, nullptr);
        listB->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
        listB->DrawInstanced(3, 1, 0, 0);
        Barrier(listB.Get(), outTex.Get(), D3D12_RESOURCE_STATE_RENDER_TARGET, kCommon);
        Barrier(listB.Get(), inTex.Get(), kBoth, kCommon);
        Barrier(listB.Get(), net, kBoth, kSrv);
        Barrier(listB.Get(), fed.Get(), kBoth, kSrv);
        if (fsrRan) Barrier(listB.Get(), fsrOut.Get(), kBoth, kSrv);
        listB->Close();
        {
            ID3D12CommandList *l[] = { listB.Get() };
            queue->ExecuteCommandLists(1, l);
        }
        queue->Signal(fout.Get(), value);
        WaitIdle();
        historyValid = useMv;
        const float ms = std::chrono::duration<float, std::milli>(std::chrono::steady_clock::now() - t0).count();
        g_shm->lastNetMs = ms;
        Store64(&g_shm->completed, value);
        if (frames <= 3 || frames % 600 == 0)
            Status("frame %llu done in %.1f ms (network %ux%u%s, passes %u%s%s, character %.2f, scene %.2f)", (unsigned long long)frames, ms,
                   nw, nh, useMv ? ", temporal" : "", fi.passes, fsrRan ? ", FSR" : "", (fi.flags & LMXXF_NR_FRAME_FLAG_FULL_NETWORK) ? ", full network" : "",
                   (fi.flags & LMXXF_NR_FRAME_FLAG_CONTROLS) ? fi.control_skin : 1.f, (fi.flags & LMXXF_NR_FRAME_FLAG_CONTROLS) ? fi.control_other : 1.f);
        return true;
    }

    int Run()
    {
        if (!InitDevice() || !InitShaders() || !InitRuntime()) return 1;
        int failures = 0;
        uint64_t lastDone = 0;
        for (;;)
        {
            Beat();
            if (WaitForSingleObject(game, 0) == WAIT_OBJECT_0)
            {
                Status("the game exited - feeder stopping");
                break;
            }
            const uint32_t g = g_shm->generation;
            if (g != gen || (gen && (g_shm->networkHeight != netCap || g_shm->upscaler != fsrModeUsed ||
                                     g_shm->fsrQuality != fsrQualityUsed || g_shm->fsrVersion != fsrVersionUsed)))
            {
                WaitIdle();
                if (!OpenGeneration(g))
                {
                    Sleep(200);
                    if (++failures > 25) return Fail("could not open the shared textures");
                    continue;
                }
                failures = 0;
                lastDone = fin->GetCompletedValue();
                g_shm->feederReadyGen = g;
            }
            // Wait (in short slices, so the heartbeat keeps going) for the game to signal a new frame.
            const uint64_t want = lastDone + 1;
            if (fin->GetCompletedValue() < want)
            {
                fin->SetEventOnCompletion(want, inEvent);
                if (WaitForSingleObject(inEvent, 50) != WAIT_OBJECT_0 && fin->GetCompletedValue() < want)
                    continue;
            }
            const uint64_t value = fin->GetCompletedValue(); // the newest frame the game has copied
            if (!Process(value))
            {
                if (++failures > 10) return Fail("the neural runtime keeps failing (see sh2nr_feeder.log)");
                queue->Signal(fout.Get(), value); // let the game go on without an answer
                WaitIdle();
            }
            else
                failures = 0;
            lastDone = value;
        }
        WaitIdle();
        DestroyFsr();
        if (ctx) { api.Drain(ctx); api.Destroy(ctx); ctx = nullptr; }
        return 0;
    }
};

int WINAPI wWinMain(HINSTANCE, HINSTANCE, PWSTR, int)
{
    int argc = 0;
    wchar_t **argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    Feeder f;
    for (int i = 1; i + 1 < argc; ++i)
    {
        if (!wcscmp(argv[i], L"--pid")) f.pid = wcstoul(argv[++i], nullptr, 10);
        else if (!wcscmp(argv[i], L"--dir")) f.dir = argv[++i];
    }
    if (f.dir.empty())
    {
        wchar_t path[MAX_PATH];
        GetModuleFileNameW(nullptr, path, MAX_PATH);
        f.dir = path;
        f.dir = f.dir.substr(0, f.dir.find_last_of(L"\\/") + 1);
    }
    while (!f.dir.empty() && f.dir.back() == L'"') f.dir.pop_back();
    if (!f.dir.empty() && f.dir.back() != L'\\' && f.dir.back() != L'/') f.dir += L'\\';
    std::wstring logPath = f.dir + L"sh2nr_feeder.log";
    g_log = _wfopen(logPath.c_str(), L"w");
    Status("SH2NR feeder starting (game pid %lu)", (unsigned long)f.pid);
    if (!f.pid) return Fail("no --pid given (the add-on starts the feeder; do not run it by hand)");
    f.game = OpenProcess(SYNCHRONIZE, FALSE, f.pid);
    if (!f.game) return Fail("the game process is not running");

    wchar_t name[128];
    swprintf(name, 128, SH2NR_SHM_FMT, (unsigned long)f.pid);
    HANDLE map = nullptr;
    for (int i = 0; i < 100 && !map; ++i)
    {
        map = OpenFileMappingW(FILE_MAP_ALL_ACCESS, FALSE, name);
        if (!map) Sleep(100);
    }
    if (!map) return Fail("the add-on's shared memory was not found");
    g_shm = (Sh2nrShared *)MapViewOfFile(map, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(Sh2nrShared));
    if (!g_shm || g_shm->magic != SH2NR_MAGIC || g_shm->version != SH2NR_VERSION)
        return Fail("the add-on and the feeder are different versions");
    g_shm->feederPid = GetCurrentProcessId();
    g_shm->feederFailed = 0;
    for (int i = 0; i < 300 && (!g_shm->luidLow && !g_shm->luidHigh); ++i) { Beat(); Sleep(100); }
    const int rc = f.Run();
    if (g_log) fclose(g_log);
    return rc;
}
