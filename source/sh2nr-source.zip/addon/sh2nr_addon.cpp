// SH2NR add-on (32-bit ReShade add-on, D3D11 through dgVoodoo2).
// Copies the finished frame into a shared texture, has the 64-bit feeder (sh2nr_feeder.exe) run
// the AMD neural network on it, and copies the answer back before present.
// SPDX-License-Identifier: GPL-3.0-or-later
// Credits: AMDNR by 3zwr1 - https://github.com/3zwr1/AMD-NR---OptiScaler (the AMD runtime host interface)
//          lmxxf (Kien) - https://github.com/lmxxf/dlss5-on-amd-9070xt-porting (MIT)
//          ReShade add-on API by Patrick Mours (BSD-3-Clause / MIT)
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <d3d11_4.h>
#include <dxgi1_2.h>
#include <cstdio>
#include <cstdarg>
#include <string>
#include <reshade.hpp>
#include "../common/sh2nr_shared.h"

extern "C" __declspec(dllexport) const char *NAME = "SH2NR";
extern "C" __declspec(dllexport) const char *DESCRIPTION =
    "AMD neural rendering (DLSS 5 NR via AMDNR's lmxxf runtime) for 32-bit / old games, through a 64-bit feeder.";

namespace
{
HMODULE g_module = nullptr;
PVOID g_veh = nullptr;
std::wstring g_dir; // folder of this add-on (the game folder)
FILE *g_log = nullptr;

void Log(const char *fmt, ...)
{
    if (!g_log)
    {
        std::wstring p = g_dir + L"sh2nr_addon.log";
        g_log = _wfopen(p.c_str(), L"a");
        if (!g_log) return;
    }
    SYSTEMTIME st; GetLocalTime(&st);
    fprintf(g_log, "%02d:%02d:%02d.%03d ", st.wHour, st.wMinute, st.wSecond, st.wMilliseconds);
    va_list ap; va_start(ap, fmt); vfprintf(g_log, fmt, ap); va_end(ap);
    fputc('\n', g_log);
    fflush(g_log);
}

bool g_firstFrame = true;
#define STEP(x) do { if (g_firstFrame) Log("step: %s", x); } while (0)

LONG CALLBACK CrashLogger(PEXCEPTION_POINTERS ep)
{
    const DWORD code = ep->ExceptionRecord->ExceptionCode;
    if (code != 0xC0000005 && code != 0xC000001D && code != 0xC0000094 && code != 0xC00000FD && code != 0xC0000409 &&
        code != 0xC0000374 && code != 0xC0000096)
        return EXCEPTION_CONTINUE_SEARCH;
    static LONG count = 0;
    if (InterlockedIncrement(&count) > 5) return EXCEPTION_CONTINUE_SEARCH;
    void *addr = ep->ExceptionRecord->ExceptionAddress;
    HMODULE m = nullptr;
    char name[MAX_PATH] = "?";
    if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCSTR)addr, &m))
        GetModuleFileNameA(m, name, MAX_PATH);
    Log("EXCEPTION 0x%08lX at %p (%s+0x%lX) thread %lu", code, addr, name, (unsigned long)((char *)addr - (char *)m),
        GetCurrentThreadId());
    return EXCEPTION_CONTINUE_SEARCH;
}

template <class T> void SafeRelease(T *&p) { if (p) { p->Release(); p = nullptr; } }

uint64_t Load64(volatile uint64_t *p) { return (uint64_t)InterlockedCompareExchange64((volatile LONG64 *)p, 0, 0); }
void Store64(volatile uint64_t *p, uint64_t v) { InterlockedExchange64((volatile LONG64 *)p, (LONG64)v); }

// ---------------- settings ----------------
struct Settings
{
    bool enabled = true;
    int toggleKey = VK_F9;
    int splitKey = VK_F10;
    float detail = 1.f, color = 1.f, mix = 1.f;
    int passes = 1;
    bool split = false;
    bool useMotion = true;
    float outputSmooth = 0.5f;
    bool fullNetwork = false;
    float sceneStructure = 1.f, characterStructure = 1.f;
    int networkHeight = 0;
    int upscaler = 0, fsrQuality = 1, fsrVersion = 0;
    float fsrSharpness = 0.3f;
    float fsrReactive = 0.5f;
    int timeoutMs = 120;
    std::string motionEffect = "MartysMods_LAUNCHPAD.fx";
    std::string motionTexture = "MotionVectorsTex";
    float motionScaleX = 1.f, motionScaleY = 1.f; // multiplied by the texture size (UV units -> pixels)
    bool launchFeeder = true;
} g_cfg;
FILETIME g_iniTime = {};

float IniF(const wchar_t *ini, const wchar_t *key, float def)
{
    wchar_t buf[64], d[64];
    swprintf(d, 64, L"%g", def);
    GetPrivateProfileStringW(L"SH2NR", key, d, buf, 64, ini);
    return (float)_wtof(buf);
}
std::string IniS(const wchar_t *ini, const wchar_t *key, const char *def)
{
    wchar_t buf[260], d[260];
    MultiByteToWideChar(CP_UTF8, 0, def, -1, d, 260);
    GetPrivateProfileStringW(L"SH2NR", key, d, buf, 260, ini);
    char out[520];
    WideCharToMultiByte(CP_UTF8, 0, buf, -1, out, 520, nullptr, nullptr);
    return out;
}

bool LoadSettings(bool force)
{
    std::wstring ini = g_dir + L"sh2nr.ini";
    WIN32_FILE_ATTRIBUTE_DATA fa;
    if (!GetFileAttributesExW(ini.c_str(), GetFileExInfoStandard, &fa))
        return false;
    if (!force && CompareFileTime(&fa.ftLastWriteTime, &g_iniTime) == 0)
        return false;
    g_iniTime = fa.ftLastWriteTime;
    const wchar_t *f = ini.c_str();
    g_cfg.enabled = GetPrivateProfileIntW(L"SH2NR", L"Enabled", 1, f) != 0;
    g_cfg.toggleKey = GetPrivateProfileIntW(L"SH2NR", L"ToggleKey", VK_F9, f);
    g_cfg.splitKey = GetPrivateProfileIntW(L"SH2NR", L"SplitKey", VK_F10, f);
    g_cfg.detail = IniF(f, L"DetailStrength", 1.f);
    g_cfg.color = IniF(f, L"ColorStrength", 1.f);
    g_cfg.mix = IniF(f, L"Mix", 1.f);
    g_cfg.passes = GetPrivateProfileIntW(L"SH2NR", L"Passes", 1, f);
    g_cfg.split = GetPrivateProfileIntW(L"SH2NR", L"SplitView", 0, f) != 0;
    g_cfg.useMotion = GetPrivateProfileIntW(L"SH2NR", L"UseMotionVectors", 1, f) != 0;
    g_cfg.outputSmooth = IniF(f, L"TemporalSmoothing", 0.5f);
    g_cfg.fullNetwork = GetPrivateProfileIntW(L"SH2NR", L"FullNetwork", 0, f) != 0;
    g_cfg.sceneStructure = IniF(f, L"SceneStructure", 1.f);
    g_cfg.networkHeight = GetPrivateProfileIntW(L"SH2NR", L"NetworkHeight", 0, f);
    {
        const std::string up = IniS(f, L"Upscaler", "native");
        g_cfg.upscaler = (_stricmp(up.c_str(), "fsr") == 0 || _stricmp(up.c_str(), "fsr4") == 0 || _stricmp(up.c_str(), "fsr3") == 0 ||
                          up == "1") ? 1 : 0;
        if (_stricmp(up.c_str(), "fsr4") == 0) g_cfg.fsrVersion = 4;
        else if (_stricmp(up.c_str(), "fsr3") == 0) g_cfg.fsrVersion = 3;
        else g_cfg.fsrVersion = 0;
        const std::string q = IniS(f, L"FsrQuality", "quality");
        const char *names[] = { "native", "quality", "balanced", "performance", "ultraperformance" };
        g_cfg.fsrQuality = 1;
        for (int i = 0; i < 5; ++i)
            if (_stricmp(q.c_str(), names[i]) == 0 || (q.size() == 1 && q[0] == char('0' + i))) g_cfg.fsrQuality = i;
        g_cfg.fsrSharpness = IniF(f, L"FsrSharpness", 0.3f);
        g_cfg.fsrReactive = IniF(f, L"FsrReactive", 0.5f);
    }
    g_cfg.characterStructure = IniF(f, L"CharacterStructure", 1.f);
    g_cfg.timeoutMs = GetPrivateProfileIntW(L"SH2NR", L"FrameTimeoutMs", 120, f);
    g_cfg.motionEffect = IniS(f, L"MotionEffect", "MartysMods_LAUNCHPAD.fx");
    g_cfg.motionTexture = IniS(f, L"MotionTexture", "MotionVectorsTex");
    g_cfg.motionScaleX = IniF(f, L"MotionScaleX", 1.f);
    g_cfg.motionScaleY = IniF(f, L"MotionScaleY", 1.f);
    g_cfg.launchFeeder = GetPrivateProfileIntW(L"SH2NR", L"LaunchFeeder", 1, f) != 0;
    return true;
}

// ---------------- state ----------------
HANDLE g_shmMap = nullptr;
Sh2nrShared *g_shm = nullptr;
HANDLE g_feeder = nullptr;
DWORD g_pid = 0;

ID3D11Device *g_dev = nullptr; // not owned
ID3D11Device5 *g_dev5 = nullptr;
ID3D11Texture2D *g_in = nullptr, *g_out = nullptr, *g_mv = nullptr;
HANDLE g_inH = nullptr, g_outH = nullptr, g_mvShare = nullptr;
ID3D11Fence *g_fin = nullptr, *g_fout = nullptr;
HANDLE g_finH = nullptr, g_foutH = nullptr;
HANDLE g_event = nullptr;
UINT g_w = 0, g_h = 0;
DXGI_FORMAT g_fmt = DXGI_FORMAT_UNKNOWN;
UINT g_mvW = 0, g_mvH = 0;
DXGI_FORMAT g_mvFmt = DXGI_FORMAT_UNKNOWN;
uint32_t g_gen = 0;
uint32_t g_fenceGen = 0;
uint64_t g_frame = 0;
bool g_broken = false;
int g_misses = 0;
bool g_keyToggle = false, g_keySplit = false;
bool g_loggedWaiting = false, g_loggedRunning = false, g_loggedNoMotion = false;

bool OpenShm()
{
    if (g_shm) return true;
    wchar_t name[128];
    swprintf(name, 128, SH2NR_SHM_FMT, (unsigned long)g_pid);
    g_shmMap = CreateFileMappingW(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE, 0, sizeof(Sh2nrShared), name);
    if (!g_shmMap) { Log("CreateFileMapping failed (%lu)", GetLastError()); return false; }
    g_shm = (Sh2nrShared *)MapViewOfFile(g_shmMap, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(Sh2nrShared));
    if (!g_shm) { Log("MapViewOfFile failed (%lu)", GetLastError()); return false; }
    ZeroMemory(g_shm, sizeof *g_shm);
    g_shm->magic = SH2NR_MAGIC;
    g_shm->version = SH2NR_VERSION;
    return true;
}

void PushSettings()
{
    if (!g_shm) return;
    g_shm->detailStrength = g_cfg.detail;
    g_shm->colorStrength = g_cfg.color;
    g_shm->mix = g_cfg.mix;
    g_shm->passes = (uint32_t)(g_cfg.passes < 1 ? 1 : g_cfg.passes > 3 ? 3 : g_cfg.passes);
    g_shm->splitView = g_cfg.split ? 1u : 0u;
    g_shm->useMotion = g_cfg.useMotion ? 1u : 0u;
    g_shm->outputSmooth = g_cfg.outputSmooth;
    g_shm->fullNetwork = g_cfg.fullNetwork ? 1u : 0u;
    g_shm->sceneStructure = g_cfg.sceneStructure;
    g_shm->networkHeight = (uint32_t)(g_cfg.networkHeight < 0 ? 0 : g_cfg.networkHeight);
    g_shm->upscaler = (uint32_t)g_cfg.upscaler;
    g_shm->fsrQuality = (uint32_t)g_cfg.fsrQuality;
    g_shm->fsrSharpness = g_cfg.fsrSharpness;
    g_shm->fsrVersion = (uint32_t)g_cfg.fsrVersion;
    g_shm->fsrReactive = g_cfg.fsrReactive;
    g_shm->characterStructure = g_cfg.characterStructure;
}

void LaunchFeeder()
{
    if (g_feeder || !g_cfg.launchFeeder) return;
    std::wstring exe = g_dir + L"sh2nr_feeder.exe";
    wchar_t cmd[1024];
    // No trailing backslash inside the quotes: \" would be read as an escaped quote.
    std::wstring d = g_dir;
    while (!d.empty() && (d.back() == L'\\' || d.back() == L'/')) d.pop_back();
    swprintf(cmd, 1024, L"\"%ls\" --pid %lu --dir \"%ls\"", exe.c_str(), (unsigned long)g_pid, d.c_str());
    STARTUPINFOW si = { sizeof si };
    PROCESS_INFORMATION pi = {};
    if (CreateProcessW(exe.c_str(), cmd, nullptr, nullptr, FALSE, CREATE_NO_WINDOW, nullptr, g_dir.c_str(), &si, &pi))
    {
        g_feeder = pi.hProcess;
        CloseHandle(pi.hThread);
        Log("feeder started (pid %lu)", pi.dwProcessId);
    }
    else
        Log("could not start %ls (error %lu) - is sh2nr_feeder.exe in the game folder?", exe.c_str(), GetLastError());
}

void ReleaseTextures()
{
    SafeRelease(g_in); SafeRelease(g_out); SafeRelease(g_mv);
    if (g_inH) { CloseHandle(g_inH); g_inH = nullptr; }
    if (g_outH) { CloseHandle(g_outH); g_outH = nullptr; }
    if (g_mvShare) { CloseHandle(g_mvShare); g_mvShare = nullptr; }
    g_w = g_h = 0;
    g_mvW = g_mvH = 0;
}

void ReleaseAll()
{
    ReleaseTextures();
    SafeRelease(g_fin); SafeRelease(g_fout);
    if (g_finH) { CloseHandle(g_finH); g_finH = nullptr; }
    if (g_foutH) { CloseHandle(g_foutH); g_foutH = nullptr; }
    SafeRelease(g_dev5);
    g_dev = nullptr;
}

ID3D11Texture2D *MakeShared(UINT w, UINT h, DXGI_FORMAT fmt, UINT bind, const wchar_t *name, HANDLE *outHandle)
{
    D3D11_TEXTURE2D_DESC d = {};
    d.Width = w; d.Height = h; d.MipLevels = 1; d.ArraySize = 1; d.Format = fmt;
    d.SampleDesc.Count = 1; d.Usage = D3D11_USAGE_DEFAULT; d.BindFlags = bind;
    d.MiscFlags = D3D11_RESOURCE_MISC_SHARED_NTHANDLE | D3D11_RESOURCE_MISC_SHARED;
    ID3D11Texture2D *t = nullptr;
    HRESULT hr = g_dev->CreateTexture2D(&d, nullptr, &t);
    if (FAILED(hr)) { Log("CreateTexture2D %ux%u fmt %u bind 0x%x failed 0x%08lx", w, h, fmt, bind, hr); return nullptr; }
    IDXGIResource1 *r1 = nullptr;
    if (FAILED(t->QueryInterface(__uuidof(IDXGIResource1), (void **)&r1)))
    { Log("no IDXGIResource1"); t->Release(); return nullptr; }
    hr = r1->CreateSharedHandle(nullptr, GENERIC_ALL, name, outHandle);
    r1->Release();
    if (FAILED(hr)) { Log("CreateSharedHandle(%ls) failed 0x%08lx", name, hr); t->Release(); return nullptr; }
    return t;
}

bool EnsureDevice(ID3D11Device *dev)
{
    if (g_dev == dev && g_dev5 && g_fin && g_fout) return true;
    ReleaseAll();
    g_dev = dev;
    if (FAILED(dev->QueryInterface(__uuidof(ID3D11Device5), (void **)&g_dev5)))
    { Log("ID3D11Device5 not available - Windows 10 1703 or newer is needed"); g_broken = true; return false; }
    wchar_t name[128];
    HRESULT hr = g_dev5->CreateFence(0, D3D11_FENCE_FLAG_SHARED, __uuidof(ID3D11Fence), (void **)&g_fin);
    if (SUCCEEDED(hr)) hr = g_dev5->CreateFence(0, D3D11_FENCE_FLAG_SHARED, __uuidof(ID3D11Fence), (void **)&g_fout);
    if (FAILED(hr)) { Log("CreateFence failed 0x%08lx", hr); g_broken = true; return false; }
    ++g_fenceGen;
    g_shm->fenceGen = g_fenceGen;
    swprintf(name, 128, SH2NR_FENCE_IN_FMT, (unsigned long)g_pid, (unsigned long)g_fenceGen);
    hr = g_fin->CreateSharedHandle(nullptr, GENERIC_ALL, name, &g_finH);
    swprintf(name, 128, SH2NR_FENCE_OUT_FMT, (unsigned long)g_pid, (unsigned long)g_fenceGen);
    if (SUCCEEDED(hr)) hr = g_fout->CreateSharedHandle(nullptr, GENERIC_ALL, name, &g_foutH);
    if (FAILED(hr)) { Log("fence CreateSharedHandle failed 0x%08lx", hr); g_broken = true; return false; }

    IDXGIDevice *dxgi = nullptr;
    if (SUCCEEDED(dev->QueryInterface(__uuidof(IDXGIDevice), (void **)&dxgi)))
    {
        IDXGIAdapter *ad = nullptr;
        if (SUCCEEDED(dxgi->GetAdapter(&ad)))
        {
            DXGI_ADAPTER_DESC desc;
            ad->GetDesc(&desc);
            g_shm->luidLow = desc.AdapterLuid.LowPart;
            g_shm->luidHigh = desc.AdapterLuid.HighPart;
            char an[128];
            WideCharToMultiByte(CP_UTF8, 0, desc.Description, -1, an, 128, nullptr, nullptr);
            Log("game device on adapter: %s", an);
            ad->Release();
        }
        dxgi->Release();
    }
    if (!g_event) g_event = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    return true;
}

bool EnsureTextures(UINT w, UINT h, DXGI_FORMAT fmt, ID3D11Texture2D *mvSrc)
{
    UINT mvW = 0, mvH = 0;
    DXGI_FORMAT mvFmt = DXGI_FORMAT_UNKNOWN;
    if (mvSrc)
    {
        D3D11_TEXTURE2D_DESC md;
        mvSrc->GetDesc(&md);
        mvW = md.Width; mvH = md.Height; mvFmt = md.Format;
    }
    if (g_in && w == g_w && h == g_h && fmt == g_fmt && mvW == g_mvW && mvH == g_mvH && mvFmt == g_mvFmt)
        return true;
    ReleaseTextures();
    ++g_gen;
    wchar_t name[128];
    swprintf(name, 128, SH2NR_TEX_IN_FMT, (unsigned long)g_pid, (unsigned long)g_gen);
    g_in = MakeShared(w, h, fmt, D3D11_BIND_SHADER_RESOURCE, name, &g_inH);
    swprintf(name, 128, SH2NR_TEX_OUT_FMT, (unsigned long)g_pid, (unsigned long)g_gen);
    g_out = MakeShared(w, h, fmt, D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET, name, &g_outH);
    if (!g_in || !g_out) { ReleaseTextures(); g_broken = true; return false; }
    if (mvSrc)
    {
        swprintf(name, 128, SH2NR_TEX_MV_FMT, (unsigned long)g_pid, (unsigned long)g_gen);
        g_mv = MakeShared(mvW, mvH, mvFmt, D3D11_BIND_SHADER_RESOURCE, name, &g_mvShare);
        if (!g_mv) Log("motion texture could not be shared - running without motion vectors");
    }
    g_w = w; g_h = h; g_fmt = fmt;
    g_mvW = g_mv ? mvW : 0; g_mvH = g_mv ? mvH : 0; g_mvFmt = g_mv ? mvFmt : DXGI_FORMAT_UNKNOWN;
    g_shm->width = w; g_shm->height = h; g_shm->dxgiFormat = fmt;
    g_shm->hasMotion = g_mv ? 1u : 0u;
    g_shm->mvWidth = g_mvW; g_shm->mvHeight = g_mvH; g_shm->mvFormat = g_mvFmt;
    g_shm->mvScaleX = g_cfg.motionScaleX * (float)g_mvW;
    g_shm->mvScaleY = g_cfg.motionScaleY * (float)g_mvH;
    g_shm->historyReset = 1;
    MemoryBarrier();
    g_shm->generation = g_gen;
    Log("shared textures generation %u: %ux%u format %u, motion %s (%ux%u format %u)", g_gen, w, h, fmt,
        g_mv ? "yes" : "no", g_mvW, g_mvH, g_mvFmt);
    return true;
}

bool FeederAlive()
{
    if (!g_shm) return false;
    if (g_feeder && WaitForSingleObject(g_feeder, 0) == WAIT_OBJECT_0)
    {
        DWORD code = 0; GetExitCodeProcess(g_feeder, &code);
        Log("feeder exited (code %lu): %s", code, g_shm->feederStatus);
        CloseHandle(g_feeder); g_feeder = nullptr;
        g_broken = true; // do not respawn in a loop
        return false;
    }
    if (g_shm->feederFailed) return false;
    const uint64_t hb = Load64(&g_shm->feederHeartbeat);
    return hb && GetTickCount64() - hb < 3000;
}

void Keys()
{
    HWND fg = GetForegroundWindow();
    DWORD fpid = 0;
    GetWindowThreadProcessId(fg, &fpid);
    const bool ours = fpid == g_pid;
    const bool t = ours && (GetAsyncKeyState(g_cfg.toggleKey) & 0x8000);
    const bool s = ours && (GetAsyncKeyState(g_cfg.splitKey) & 0x8000);
    if (t && !g_keyToggle)
    {
        g_cfg.enabled = !g_cfg.enabled;
        if (g_shm) g_shm->historyReset = 1;
        Log("neural rendering %s (toggle key)", g_cfg.enabled ? "ON" : "OFF");
    }
    if (s && !g_keySplit)
    {
        g_cfg.split = !g_cfg.split;
        Log("split view %s", g_cfg.split ? "ON" : "OFF");
    }
    g_keyToggle = t; g_keySplit = s;
}

// ABI note: this add-on is built with MinGW, ReShade with MSVC. MSVC returns structs from member
// functions through a hidden pointer and GCC returns small ones in registers, so no ReShade method
// that returns a struct (resource, effect_texture_variable, ...) may be called from here. Views are
// native D3D11 pointers on this API, so the resource is read through D3D11 instead.
ID3D11Texture2D *TextureFromView(uint64_t viewHandle)
{
    if (!viewHandle) return nullptr;
    auto *view = reinterpret_cast<ID3D11View *>(viewHandle);
    ID3D11Resource *r = nullptr;
    view->GetResource(&r); // AddRef'd
    if (!r) return nullptr;
    ID3D11Texture2D *t = nullptr;
    r->QueryInterface(__uuidof(ID3D11Texture2D), (void **)&t); // AddRef'd
    r->Release();
    return t; // caller releases
}

struct MotionSearch
{
    const char *name;
    reshade::api::effect_texture_variable found;
};

void OnTextureVariable(reshade::api::effect_runtime *rt, reshade::api::effect_texture_variable var, void *user)
{
    auto *ms = static_cast<MotionSearch *>(user);
    if (ms->found.handle) return;
    char name[256] = {};
    size_t size = sizeof name;
    rt->get_texture_variable_name(var, name, &size);
    if (_stricmp(name, ms->name) == 0) ms->found = var;
}

ID3D11Texture2D *FindMotion(reshade::api::effect_runtime *rt)
{
    if (!g_cfg.useMotion) return nullptr;
    MotionSearch ms = { g_cfg.motionTexture.c_str(), {} };
    rt->enumerate_texture_variables(g_cfg.motionEffect.c_str(), &OnTextureVariable, &ms);
    if (ms.found.handle == 0)
    {
        if (!g_loggedNoMotion)
        {
            g_loggedNoMotion = true;
            Log("motion texture '%s' in '%s' not found (is the effect installed and enabled?) - no motion vectors, no temporal history",
                g_cfg.motionTexture.c_str(), g_cfg.motionEffect.c_str());
        }
        return nullptr;
    }
    reshade::api::resource_view srv = {}, srvSrgb = {};
    rt->get_texture_binding(ms.found, &srv, &srvSrgb);
    ID3D11Texture2D *t = TextureFromView(srv.handle);
    if (!t) return nullptr;
    t->Release(); // the effect runtime keeps it alive for this frame
    if (g_loggedNoMotion)
    {
        g_loggedNoMotion = false;
        Log("motion texture found");
    }
    return t;
}

reshade::api::effect_runtime *g_rt = nullptr; // for the motion texture lookup only

// Runs in ReShade's present event: before ReShade draws its effects and its menu, so the network sees
// the game's own picture (Launchpad's motion vectors are then the previous frame's, one frame late).
// Everything here goes through DXGI / D3D11 COM calls on the native swap chain.
// The frame's work. Runs after ReShade's effects (reshade_finish_effects), so Launchpad's motion vectors are this
// frame's; falls back to the present event when no effects run at all. Only the swap chain stored by the present
// event is used, through DXGI / D3D11 (no ReShade call that returns a struct - see TextureFromView).
reshade::api::swapchain *g_sc = nullptr;
uint64_t g_presents = 0, g_lastFinishPresent = 0;
bool g_loggedPath = false;

void DoFrame(reshade::api::swapchain *sc)
{
    if (g_broken || !sc) return;
    reshade::api::device *dev = sc->get_device();
    if (!dev) return;
    if (dev->get_api() != reshade::api::device_api::d3d11)
    {
        static bool once = false;
        if (!once) { once = true; Log("the game is not rendering through D3D11 (api 0x%x) - set up dgVoodoo2 (see README)", (unsigned)dev->get_api()); }
        return;
    }
    if (!OpenShm()) { g_broken = true; return; }
    if (LoadSettings(false)) { PushSettings(); Log("sh2nr.ini (re)loaded"); }
    Keys();
    PushSettings();
    if (!g_cfg.enabled) return;

    STEP("swap chain");
    const uint64_t nativeSc = sc->get_native();
    const uint64_t nativeDev = dev->get_native();
    if (g_firstFrame) Log("native swap chain %p, native device %p", (void *)(uintptr_t)nativeSc, (void *)(uintptr_t)nativeDev);
    auto *dxgiSc = reinterpret_cast<IDXGISwapChain *>(nativeSc);
    if (!dxgiSc) return;
    ID3D11Device *d3d = nullptr;
    if (FAILED(dxgiSc->GetDevice(__uuidof(ID3D11Device), (void **)&d3d)) || !d3d)
    { Log("IDXGISwapChain::GetDevice failed"); g_broken = true; return; }
    d3d->Release(); // the swap chain keeps it alive
    if (g_firstFrame) Log("device from swap chain %p", (void *)d3d);

    STEP("device");
    if (!EnsureDevice(d3d)) return;
    STEP("back buffer");
    ID3D11Texture2D *bb = nullptr;
    if (FAILED(dxgiSc->GetBuffer(0, __uuidof(ID3D11Texture2D), (void **)&bb)) || !bb)
    { Log("IDXGISwapChain::GetBuffer failed"); g_broken = true; return; }
    D3D11_TEXTURE2D_DESC bd;
    bb->GetDesc(&bd);
    if (bd.SampleDesc.Count != 1)
    {
        static bool once = false;
        if (!once) { once = true; Log("back buffer is multisampled (%u) - turn MSAA off in dgVoodoo2", bd.SampleDesc.Count); }
        bb->Release();
        return;
    }
    STEP("motion lookup");
    ID3D11Texture2D *mvSrc = g_rt ? FindMotion(g_rt) : nullptr;
    {
        static bool once = false;
        if (!once) { once = true; Log("first frame: back buffer %ux%u format %u, motion texture %s", bd.Width, bd.Height, bd.Format, mvSrc ? "found" : "not found"); }
    }
    STEP("shared textures");
    if (!EnsureTextures(bd.Width, bd.Height, bd.Format, mvSrc)) { bb->Release(); return; }
    STEP("launch feeder");
    LaunchFeeder();
    g_firstFrame = false;

    if (!FeederAlive() || g_shm->feederReadyGen != g_gen)
    {
        if (!g_loggedWaiting) { g_loggedWaiting = true; Log("waiting for the feeder (status: %s)", g_shm->feederStatus); }
        bb->Release();
        return;
    }
    if (!g_loggedRunning) { g_loggedRunning = true; Log("feeder ready - neural rendering running"); }

    ID3D11DeviceContext *ctx = nullptr;
    d3d->GetImmediateContext(&ctx);
    ID3D11DeviceContext4 *ctx4 = nullptr;
    if (!ctx || FAILED(ctx->QueryInterface(__uuidof(ID3D11DeviceContext4), (void **)&ctx4)))
    { Log("no ID3D11DeviceContext4"); g_broken = true; if (ctx) ctx->Release(); bb->Release(); return; }

    const uint64_t n = ++g_frame;
    ctx->CopyResource(g_in, bb);
    if (g_mv && mvSrc) ctx->CopyResource(g_mv, mvSrc);
    ctx4->Signal(g_fin, n);
    ctx->Flush();
    Store64(&g_shm->requested, n);

    bool done = g_fout->GetCompletedValue() >= n;
    if (!done)
    {
        g_fout->SetEventOnCompletion(n, g_event);
        done = WaitForSingleObject(g_event, (DWORD)g_cfg.timeoutMs) == WAIT_OBJECT_0 || g_fout->GetCompletedValue() >= n;
    }
    if (done)
    {
        ctx->CopyResource(bb, g_out);
        g_misses = 0;
        if (n <= 3) Log("frame %llu answered (network %.1f ms)", (unsigned long long)n, g_shm->lastNetMs);
    }
    else if (n <= 3)
        Log("frame %llu: no answer within %d ms", (unsigned long long)n, g_cfg.timeoutMs);
    else if (++g_misses == 30)
        Log("30 frames in a row without an answer within %d ms (last network time %.1f ms) - raise FrameTimeoutMs or lower the resolution",
            g_cfg.timeoutMs, g_shm->lastNetMs);
    ctx4->Release();
    ctx->Release();
    bb->Release();
}

void OnInitRuntime(reshade::api::effect_runtime *rt) { g_rt = rt; }

void OnPresent(reshade::api::command_queue *, reshade::api::swapchain *sc, const reshade::api::rect *, const reshade::api::rect *,
               uint32_t, const reshade::api::rect *)
{
    ++g_presents;
    g_sc = sc;
    // No effect pass for a few frames (all effects off): do the work here instead, motion one frame late.
    if (g_presents - g_lastFinishPresent > 3)
    {
        if (!g_loggedPath) { g_loggedPath = true; Log("no ReShade effect pass seen - working in the present event (turn Launchpad on)"); }
        DoFrame(sc);
    }
}

void OnFinishEffects(reshade::api::effect_runtime *, reshade::api::command_list *, reshade::api::resource_view, reshade::api::resource_view)
{
    g_lastFinishPresent = g_presents;
    if (g_loggedPath) { g_loggedPath = false; Log("working after ReShade's effects again (motion vectors of this frame)"); }
    if (g_sc) DoFrame(g_sc);
}

void OnDestroyRuntime(reshade::api::effect_runtime *rt)
{
    if (g_rt == rt) g_rt = nullptr;
}

void OnDestroySwapchain(reshade::api::swapchain *sc, bool)
{
    if (g_sc == sc) g_sc = nullptr;
    ReleaseTextures(); // new textures (and a new generation) at the next present
}
} // namespace

BOOL APIENTRY DllMain(HMODULE mod, DWORD reason, LPVOID)
{
    switch (reason)
    {
    case DLL_PROCESS_ATTACH:
    {
        g_module = mod;
        wchar_t path[MAX_PATH];
        GetModuleFileNameW(mod, path, MAX_PATH);
        std::wstring p = path;
        g_dir = p.substr(0, p.find_last_of(L"\\/") + 1);
        g_pid = GetCurrentProcessId();
        g_veh = AddVectoredExceptionHandler(1, CrashLogger);
        if (!reshade::register_addon(mod))
            return FALSE;
        LoadSettings(true);
        Log("SH2NR add-on loaded (pid %lu). Toggle key 0x%X, split key 0x%X", (unsigned long)g_pid, g_cfg.toggleKey, g_cfg.splitKey);
        reshade::register_event<reshade::addon_event::present>(OnPresent);
        reshade::register_event<reshade::addon_event::reshade_finish_effects>(OnFinishEffects);
        reshade::register_event<reshade::addon_event::init_effect_runtime>(OnInitRuntime);
        reshade::register_event<reshade::addon_event::destroy_effect_runtime>(OnDestroyRuntime);
        reshade::register_event<reshade::addon_event::destroy_swapchain>(OnDestroySwapchain);
        break;
    }
    case DLL_PROCESS_DETACH:
        Log("process exiting (frames sent: %llu)", (unsigned long long)g_frame);
        if (g_veh) { RemoveVectoredExceptionHandler(g_veh); g_veh = nullptr; }
        reshade::unregister_addon(mod);
        if (g_feeder) { CloseHandle(g_feeder); g_feeder = nullptr; } // the feeder exits on its own when the game does
        if (g_log) fclose(g_log);
        break;
    }
    return TRUE;
}
