#!/bin/sh
# Cross-builds SH2NR with mingw-w64 (posix threads). Needs ReShade's include/ in third_party/reshade/include.
set -e
mkdir -p build/caseshim
for h in Windows Psapi Unknwn; do l=$(echo $h | tr A-Z a-z); echo "#include <$l.h>" > build/caseshim/$h.h; done
x86_64-w64-mingw32-g++-posix -std=c++17 -O2 -Wall -DWIDL_EXPLICIT_AGGREGATE_RETURNS -municode -mwindows -Ifeeder \
  feeder/sh2nr_feeder.cpp -o build/sh2nr_feeder.exe -ld3d12 -ldxgi -lshell32 -static -static-libgcc -static-libstdc++
i686-w64-mingw32-g++-posix -std=c++17 -O2 -Wall -Wno-attributes -DWIDL_EXPLICIT_AGGREGATE_RETURNS -shared \
  -Ibuild/caseshim -Ithird_party/reshade/include addon/sh2nr_addon.cpp -o build/sh2nr.addon32 -static -static-libgcc -static-libstdc++
