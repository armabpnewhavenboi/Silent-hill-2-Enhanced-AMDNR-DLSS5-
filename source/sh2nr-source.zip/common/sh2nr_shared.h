// SH2NR - shared definitions between the 32-bit ReShade add-on and the 64-bit feeder.
// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>

#define SH2NR_MAGIC   0x524E3253u /* 'S2NR' */
#define SH2NR_VERSION 6u

// Names are built as  Local\SH2NR_<gamePid>_<what>[_<generation>]
#define SH2NR_SHM_FMT     L"Local\\SH2NR_%lu_ctl"
#define SH2NR_TEX_IN_FMT  L"Local\\SH2NR_%lu_in_%lu"
#define SH2NR_TEX_OUT_FMT L"Local\\SH2NR_%lu_out_%lu"
#define SH2NR_TEX_MV_FMT  L"Local\\SH2NR_%lu_mv_%lu"
#define SH2NR_FENCE_IN_FMT  L"Local\\SH2NR_%lu_fin_%lu"
#define SH2NR_FENCE_OUT_FMT L"Local\\SH2NR_%lu_fout_%lu"

#pragma pack(push, 8)
typedef struct Sh2nrShared
{
    uint32_t magic;
    uint32_t version;

    // ---- written by the add-on ----
    uint32_t luidLow;          // adapter of the game's D3D11 device
    int32_t  luidHigh;
    volatile uint32_t generation;   // bumped every time the shared textures are recreated
    uint32_t width, height;    // back buffer size
    uint32_t dxgiFormat;       // back buffer (and shared texture) format
    uint32_t hasMotion;        // 1 = a motion texture is shared for this generation
    uint32_t mvWidth, mvHeight;
    uint32_t mvFormat;
    float    mvScaleX, mvScaleY; // motion value * scale = displacement in pixels to the previous frame
    volatile uint64_t requested;    // last frame value signalled on the in-fence
    volatile uint32_t historyReset; // add-on asks for a history reset (toggle, resize, load screen)

    // settings (from sh2nr.ini, the add-on reads it and hot-reloads it)
    float    detailStrength;   // 0..1
    float    colorStrength;    // 0..1
    float    mix;              // 0..1 final blend with the original
    uint32_t passes;           // 1..3
    uint32_t splitView;        // 1 = left half original, right half NR
    uint32_t useMotion;        // 1 = feed motion vectors (temporal history)
    float    outputSmooth;     // 0..0.8 temporal smoothing (needs motion)
    uint32_t fullNetwork;      // 1 = all 71 blocks

    // ---- written by the feeder ----
    volatile uint32_t feederPid;
    volatile uint64_t feederHeartbeat; // GetTickCount64 of the feeder's last loop
    volatile uint32_t feederReadyGen;  // generation the feeder has opened
    volatile uint32_t feederFailed;    // 1 = gave up; see feederStatus
    volatile uint64_t completed;       // last frame value signalled on the out-fence
    volatile float    lastNetMs;       // GPU+HIP time of the last frame, ms
    uint32_t netWidth, netHeight;      // size the network actually runs at
    char     feederStatus[256];

    // ---- written by the add-on (v2) ----
    volatile uint32_t fenceGen;        // bumped when the shared fences are recreated (new device)

    // ---- settings (v3): lmxxf's character mask controls, 0..4, 1 = the shipped network ----
    float    sceneStructure;           // structure of everything that is not a character
    float    characterStructure;       // structure of characters (faces, skin, clothes)

    // ---- settings (v4) ----
    uint32_t networkHeight;            // 0 = as large as the network takes (1080), else cap: 720 / 900 / 1080

    // ---- settings (v5): AMD FSR upscaling of the network's answer ----
    uint32_t upscaler;                 // 0 = native (full-res frame + the network's change), 1 = FSR (4 on RX 9000, else 3.1)
    uint32_t fsrQuality;               // 0 native AA, 1 quality (1.5x), 2 balanced (1.7x), 3 performance (2x), 4 ultra perf (3x)
    float    fsrSharpness;             // 0..1, 0 = off
    uint32_t fsrVersion;               // 0 = newest the driver/DLL offers, 3 = force FSR 3.x, 4 = force FSR 4.x

    // ---- written by the feeder (v5) ----
    char     upscalerStatus[96];       // e.g. "FSR 4.1.1, 1706x960 -> 2560x1440"

    // ---- settings (v6) ----
    float    fsrReactive;              // 0..1: how much FSR trusts this frame over its history (higher = less ghosting)
} Sh2nrShared;
#pragma pack(pop)
